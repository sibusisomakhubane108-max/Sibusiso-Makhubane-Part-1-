package sibusisopart1;

import java.util.Scanner;

public class SibusisoPart1 {

    public String name;
    public String surname;
    public String username;
    public String password;
    public String cellPhoneNumber;

    public static void main(String[] args) {

        String name;
        String surname;
        String username;
        String cellPhoneNumber;
        String password;

        Scanner inputDevice = new Scanner(System.in);

        // Enter name
        System.out.print("Please enter your name: ");
        name = inputDevice.nextLine();

        // Enter surname
        System.out.print("Please enter your surname: ");
        surname = inputDevice.nextLine();

        // Register username
        while (true) {
            System.out.print("Please enter username: ");
            username = inputDevice.nextLine();

            if (checkUserName(username)) {
                System.out.println("Username successfully captured");
                break;
            } else {
                System.out.println("Username is not correctly formatted.");
                System.out.println("Username must contain an underscore.");
                System.out.println("Username must not be more than 5 characters.");
            }
        }

        // Register password
        while (true) {
            System.out.print("Please enter password: ");
            password = inputDevice.nextLine();

            if (checkPassword(password)) {
                System.out.println("Password successfully captured");
                break;
            } else {
                System.out.println("Password is not correctly formatted.");
                System.out.println("Password must contain at least 8 characters.");
                System.out.println("Password must contain a capital letter.");
                System.out.println("Password must contain a number.");
                System.out.println("Password must contain a special character.");
            }
        }

        // Register cell phone number
        while (true) {
            System.out.print("Please enter cell phone number: ");
            cellPhoneNumber = inputDevice.nextLine();

            if (checkCellPhoneNumber(cellPhoneNumber)) {
                System.out.println("Cell phone number successfully added.");
                break;
            } else {
                System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
            }
        }

        // Registration successful
        System.out.println();
        System.out.println("Registration successfully completed!");
        System.out.println("Welcome " + name + " " + surname);

        // Create user object
        SibusisoPart1 user = new SibusisoPart1();

        user.name = name;
        user.surname = surname;
        user.username = username;
        user.password = password;
        user.cellPhoneNumber = cellPhoneNumber;

        // Login
        login.loginUser(inputDevice, user);

        inputDevice.close();
    }

    // Check username
    public static boolean checkUserName(String username) {
        return username.length() <= 5 && username.contains("_");
    }

    // Check cell phone number
    public static boolean checkCellPhoneNumber(String cellPhoneNumber) {
        return cellPhoneNumber.startsWith("+")
                && cellPhoneNumber.length() <= 13;
    }

    // Check password
    public static boolean checkPassword(String password) {

        if (password.length() < 8) {
            return false;
        }

        boolean hasCapitalLetter = false;
        boolean hasNumber = false;
        boolean hasSpecialCharacter = false;

        for (int i = 0; i < password.length(); i++) {

            char ch = password.charAt(i);

            if (Character.isUpperCase(ch)) {
                hasCapitalLetter = true;
            }

            if (Character.isDigit(ch)) {
                hasNumber = true;
            }

            if (!Character.isLetterOrDigit(ch)) {
                hasSpecialCharacter = true;
            }
        }

        return hasCapitalLetter && hasNumber && hasSpecialCharacter;
    }
}