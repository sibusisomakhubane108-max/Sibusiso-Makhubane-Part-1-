package sibusisopart1;

import java.util.Scanner;
import org.junit.Test;
import static org.junit.Assert.*;

public class SibusisoPart1Test {

    // Test username validation
    @Test
    public void testCheckUserName() {
        assertTrue(
            "Valid username should contain an underscore and be 5 characters or less",
            SibusisoPart1.checkUserName("kyl_1")
        );

        assertFalse(
            "Username without an underscore should be invalid",
            SibusisoPart1.checkUserName("kyle1")
        );

        assertFalse(
            "Username longer than 5 characters should be invalid",
            SibusisoPart1.checkUserName("kyle_123")
        );
    }

    // Test password validation
    @Test
    public void testCheckPassword() {
        assertTrue(
            "Valid password should contain 8+ characters, capital letter, number and special character",
            SibusisoPart1.checkPassword("Password1!")
        );

        assertFalse(
            "Password without a capital letter should be invalid",
            SibusisoPart1.checkPassword("password1!")
        );

        assertFalse(
            "Password without a number should be invalid",
            SibusisoPart1.checkPassword("Password!")
        );

        assertFalse(
            "Password without a special character should be invalid",
            SibusisoPart1.checkPassword("Password1")
        );

        assertFalse(
            "Password shorter than 8 characters should be invalid",
            SibusisoPart1.checkPassword("Pass1!")
        );
    }

    // Test cell phone number validation
    @Test
    public void testCheckCellPhoneNumber() {
        assertTrue(
            "Phone number with international code should be valid",
            SibusisoPart1.checkCellPhoneNumber("+27821234567")
        );

        assertFalse(
            "Phone number without international code should be invalid",
            SibusisoPart1.checkCellPhoneNumber("0821234567")
        );

        assertFalse(
            "Phone number longer than 13 characters should be invalid",
            SibusisoPart1.checkCellPhoneNumber("+27821234567890")
        );
    }

    // Test successful login
    @Test
    public void testSuccessfulLogin() {

        SibusisoPart1 user = new SibusisoPart1();

        user.name = "Sibusiso";
        user.surname = "Mkhize";
        user.username = "sib_1";
        user.password = "Password1!";
        user.cellPhoneNumber = "+27821234567";

        Scanner input = new Scanner(
            "sib_1\nPassword1!\n"
        );

        boolean result = login.loginUser(input, user);

        assertTrue(
            "Login should be successful when username and password are correct",
            result
        );
    }

    // Test unsuccessful login followed by successful login
    @Test
    public void testLoginWithIncorrectDetails() {

        SibusisoPart1 user = new SibusisoPart1();

        user.name = "Sibusiso";
        user.surname = "Mkhize";
        user.username = "sib_1";
        user.password = "Password1!";
        user.cellPhoneNumber = "+27821234567";

        Scanner input = new Scanner(
            "wrong_username\nwrong_password\n"
            + "sib_1\nPassword1!\n"
        );

        boolean result = login.loginUser(input, user);

        assertTrue(
            "Login should eventually be successful after correct details are entered",
            result
        );
    }

    // Test login status message
    @Test
    public void testReturnLoginStatus() {

        SibusisoPart1 user = new SibusisoPart1();

        user.name = "Sibusiso";
        user.surname = "Mkhize";
        user.username = "sib_1";
        user.password = "Password1!";

        String successMessage =
            login.returnLoginStatus(user, true);

        assertEquals(
            "Welcome Sibusiso, Mkhize it is great to see you again.",
            successMessage
        );

        String failureMessage =
            login.returnLoginStatus(user, false);

        assertEquals(
            "Username or password is incorrect, please try again.",
            failureMessage
        );
    }
}